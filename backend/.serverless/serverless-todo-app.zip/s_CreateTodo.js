
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kelvinogirisen',
  applicationName: 'serverless-todo-app',
  appUid: 'kLp7wgy4Hd3RM3bmCG',
  orgUid: 'de5de9b1-c388-4a8e-8a5c-6f004885aba2',
  deploymentUid: '911542e8-869d-4f19-8f48-deaf1427cd20',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-CreateTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}